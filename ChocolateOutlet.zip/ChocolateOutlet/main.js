document.addEventListener("DOMContentLoaded", () => {
    // Register ScrollTrigger
    gsap.registerPlugin(ScrollTrigger);

    // Navbar scroll effect
    const navbar = document.getElementById("navbar");
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            navbar.classList.add("nav-scrolled");
        } else {
            navbar.classList.remove("nav-scrolled");
        }
    });

    // Create Sparkles
    const sparkleContainer = document.getElementById("sparkle-container");
    if (sparkleContainer) {
        for (let i = 0; i < 40; i++) {
            const sparkle = document.createElement("div");
            sparkle.classList.add("sparkle");

            // Random positioning across viewport
            sparkle.style.left = `${Math.random() * 100}vw`;
            sparkle.style.top = `${Math.random() * 100}vh`;

            // Random size
            const size = Math.random() * 2 + 1;
            sparkle.style.width = `${size}px`;
            sparkle.style.height = `${size}px`;

            sparkleContainer.appendChild(sparkle);

            // Animate sparkles
            gsap.to(sparkle, {
                opacity: Math.random() * 0.6 + 0.1, // Random max opacity
                scale: Math.random() * 1.5 + 0.5,
                duration: Math.random() * 3 + 2,
                repeat: -1,
                yoyo: true,
                delay: Math.random() * 2,
                ease: "sine.inOut"
            });
        }
    }

    // Hero Section Load Animations
    const tl = gsap.timeline();

    tl.from("[data-gsap='fade-up']", {
        y: 30,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power3.out",
        delay: 0.2
    });

    tl.from(".hero-image-wrapper", {
        x: 50,
        opacity: 0,
        duration: 1.2,
        ease: "power2.out",
        rotation: 5
    }, "-=0.8");

    // Parallax effect on mouse move for hero image
    document.addEventListener("mousemove", (e) => {
        const x = (e.clientX / window.innerWidth - 0.5) * 30;
        const y = (e.clientY / window.innerHeight - 0.5) * 30;

        gsap.to(".hero-img", {
            x: x,
            y: y,
            duration: 1,
            ease: "power1.out"
        });

        // Background parallax elements
        gsap.utils.toArray(".parallax-el").forEach(el => {
            const speed = el.getAttribute("data-speed");
            gsap.to(el, {
                x: x * speed,
                y: y * speed,
                duration: 1,
                ease: "power1.out"
            });
        });
    });

    // Scroll Elements Animations Setup
    const setupScrollAnimations = () => {
        const scrollElements = gsap.utils.toArray('.scroll-trigger-element');

        scrollElements.forEach((el) => {
            const animType = el.getAttribute('data-anim');
            let vars = {
                scrollTrigger: {
                    trigger: el,
                    start: "top 85%", // Trigger when top of element hits 85% of viewport
                    toggleActions: "play none none reverse", // Play forward on enter, reverse on leave up
                },
                duration: 1,
                opacity: 0,
                ease: "power3.out"
            };

            switch (animType) {
                case 'fade-up':
                    vars.y = 50;
                    break;
                case 'fade-right':
                    vars.x = -50;
                    break;
                case 'fade-left':
                    vars.x = 50;
                    break;
                case 'zoom-in':
                    vars.scale = 0.8;
                    vars.duration = 1.5;
                    vars.ease = "back.out(1.2)";
                    break;
            }

            gsap.from(el, vars);
        });
    };

    setupScrollAnimations();
});
