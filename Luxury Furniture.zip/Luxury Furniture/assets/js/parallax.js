const initParallax = () => {
  if (!window.gsap || !window.ScrollTrigger) return;

  gsap.utils.toArray("[data-parallax]").forEach((image) => {
    if (image.dataset.parallaxReady === "true") return;
    image.dataset.parallaxReady = "true";

    gsap.to(image, {
      yPercent: 12,
      ease: "none",
      scrollTrigger: {
        trigger: image.parentElement,
        scrub: true
      }
    });
  });
};

document.addEventListener("DOMContentLoaded", initParallax);
document.addEventListener("partials:loaded", initParallax);
