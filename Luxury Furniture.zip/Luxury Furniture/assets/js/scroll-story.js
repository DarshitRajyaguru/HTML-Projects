const initScrollStories = () => {
  if (!window.gsap || !window.ScrollTrigger) return;

  gsap.utils.toArray("[data-story]").forEach((section) => {
    if (section.dataset.storyReady === "true") return;
    section.dataset.storyReady = "true";

    const image = section.querySelector("[data-parallax]");
    const copy = section.querySelector(".story-copy");
    if (!image || !copy) return;

    const timeline = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: "top 70%",
        end: "bottom 30%",
        scrub: true
      }
    });

    timeline
      .fromTo(copy, { opacity: 0, y: 60 }, { opacity: 1, y: 0, duration: 1 })
      .fromTo(section, { backgroundColor: "transparent" }, { backgroundColor: "#001d3d", duration: 1 }, 0);
  });
};

document.addEventListener("DOMContentLoaded", initScrollStories);
document.addEventListener("partials:loaded", initScrollStories);
