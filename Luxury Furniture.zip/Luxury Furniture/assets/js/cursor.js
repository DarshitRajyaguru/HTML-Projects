const initCursor = () => {
  if (window.innerWidth < 768) return;

  const dot = document.querySelector("#cursor-dot");
  const ring = document.querySelector("#cursor-ring");
  if (!dot || !ring) return;
  if (document.body.dataset.cursorReady === "true") return;

  document.body.dataset.cursorReady = "true";

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let ringX = mouseX;
  let ringY = mouseY;

  window.addEventListener("mousemove", (event) => {
    mouseX = event.clientX;
    mouseY = event.clientY;
    dot.style.transform = `translate3d(${mouseX}px, ${mouseY}px, 0) translate(-50%, -50%)`;
    document.body.classList.add("cursor-visible");
  });

  const animate = () => {
    ringX += (mouseX - ringX) * 0.16;
    ringY += (mouseY - ringY) * 0.16;
    ring.style.transform = `translate3d(${ringX}px, ${ringY}px, 0) translate(-50%, -50%)`;
    requestAnimationFrame(animate);
  };

  animate();

  document.addEventListener("mouseleave", () => {
    document.body.classList.remove("cursor-visible", "cursor-hover");
  });

  document.addEventListener("mouseenter", () => {
    document.body.classList.add("cursor-visible");
  });

  document.querySelectorAll("a, button, input, textarea, select").forEach((element) => {
    element.addEventListener("mouseenter", () => document.body.classList.add("cursor-hover"));
    element.addEventListener("mouseleave", () => document.body.classList.remove("cursor-hover"));
  });
};

document.addEventListener("DOMContentLoaded", initCursor);
document.addEventListener("partials:loaded", initCursor);
