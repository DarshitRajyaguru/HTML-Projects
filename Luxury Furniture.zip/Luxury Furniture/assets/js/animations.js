const initAnimations = () => {
  if (!window.gsap || !window.ScrollTrigger) return;

  gsap.registerPlugin(ScrollTrigger);

  gsap.utils.toArray("[data-animate='fade-up']").forEach((element) => {
    if (element.dataset.animatedReady === "true") return;
    element.dataset.animatedReady = "true";

    gsap.to(element, {
      opacity: 1,
      y: 0,
      duration: 1,
      ease: "power3.out",
      scrollTrigger: {
        trigger: element,
        start: "top 85%"
      }
    });
  });

  gsap.utils.toArray("[data-animate='reveal']").forEach((element) => {
    if (element.dataset.revealReady === "true") return;
    element.dataset.revealReady = "true";

    gsap.fromTo(
      element,
      { opacity: 0, y: 50, clipPath: "inset(0 0 100% 0)" },
      {
        opacity: 1,
        y: 0,
        clipPath: "inset(0 0 0% 0)",
        duration: 1.2,
        ease: "power4.out",
        scrollTrigger: {
          trigger: element,
          start: "top 80%"
        }
      }
    );
  });

  ScrollTrigger.refresh();
};

document.addEventListener("DOMContentLoaded", initAnimations);
document.addEventListener("partials:loaded", initAnimations);
