const headerTemplate = `
  <header class="site-header">
    <div class="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-4 md:px-10">
      <a href="index.html" class="text-2xl font-display tracking-[0.2em] text-white">AUREON</a>
      <nav class="hidden items-center gap-8 xl:flex">
        <a href="index.html" class="nav-link">Home</a>
        <a href="about.html" class="nav-link">About</a>
        <div class="group relative">
          <a href="properties.html" class="nav-link">Properties</a>
          <div class="mega-menu">
            <div>
              <p class="mega-label">Property Categories</p>
              <a href="properties.html">Modern Villas</a>
              <a href="properties.html">Waterfront Homes</a>
              <a href="property-details.html">Featured Residence</a>
            </div>
            <div>
              <p class="mega-label">Design Services</p>
              <a href="interiors.html">Interior Concepts</a>
              <a href="contact.html">Private Viewings</a>
              <a href="contact.html">Investment Advisory</a>
            </div>
          </div>
        </div>
        <a href="interiors.html" class="nav-link">Interiors</a>
        <a href="furniture-shop.html" class="nav-link">Furniture</a>
        <a href="blog.html" class="nav-link">Blog</a>
        <a href="contact.html" class="nav-link">Contact</a>
      </nav>
      <div class="hidden items-center gap-4 xl:flex">
        <button class="icon-button" aria-label="Search">&#8989;</button>
        <button class="icon-button" aria-label="Wishlist">&#9825;</button>
        <button class="icon-button" aria-label="Cart">&#128717;</button>
        <a href="contact.html" class="btn-primary header-cta">Let's Talk</a>
      </div>
      <button id="mobile-menu-toggle" class="icon-button xl:hidden" aria-label="Open navigation">&#9776;</button>
    </div>
    <div id="mobile-menu" class="mobile-menu">
      <div class="flex items-center justify-between">
        <a href="index.html" class="text-2xl font-display tracking-[0.2em] text-white">AUREON</a>
        <button id="mobile-menu-close" class="icon-button" aria-label="Close navigation">&#10005;</button>
      </div>
      <nav class="mt-10 flex flex-col gap-5 text-lg">
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="properties.html">Properties</a>
        <a href="interiors.html">Interiors</a>
        <a href="furniture-shop.html">Furniture</a>
        <a href="blog.html">Blog</a>
        <a href="contact.html">Contact</a>
      </nav>
      <a href="contact.html" class="btn-primary mt-8 w-full text-center">Book Consultation</a>
    </div>
  </header>
`;

const footerTemplate = `
  <footer class="border-t border-white/10 bg-[#020b1f]">
    <div class="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:grid-cols-2 md:px-10 xl:grid-cols-5">
      <div class="xl:col-span-2">
        <a href="index.html" class="text-2xl font-display tracking-[0.2em] text-white">AUREON</a>
        <p class="mt-4 max-w-md text-white/65">Luxury real estate, elevated interiors, and collectible furniture shaped into one high-touch lifestyle brand.</p>
      </div>
      <div>
        <p class="footer-title">Quick Links</p>
        <div class="footer-links">
          <a href="about.html">About</a>
          <a href="properties.html">Properties</a>
          <a href="interiors.html">Interiors</a>
          <a href="blog.html">Blog</a>
        </div>
      </div>
      <div>
        <p class="footer-title">Services</p>
        <div class="footer-links">
          <a href="properties.html">Property Advisory</a>
          <a href="interiors.html">Interior Design</a>
          <a href="furniture-shop.html">Furniture Curation</a>
          <a href="contact.html">Private Consultations</a>
        </div>
      </div>
      <div>
        <p class="footer-title">Contact</p>
        <div class="footer-links">
          <a href="mailto:hello@aureonestates.com">hello@aureonestates.com</a>
          <a href="tel:+12125550148">+1 (212) 555-0148</a>
          <span>18 Mercer Street, New York, NY</span>
          <span>Instagram / Pinterest / LinkedIn</span>
        </div>
        <form class="mt-6 space-y-3">
          <input class="form-field w-full" type="email" placeholder="Newsletter Email">
          <button class="btn-primary w-full" type="submit">Subscribe</button>
        </form>
      </div>
    </div>
  </footer>
`;

const renderIncludes = () => {
  document.querySelectorAll("[data-include]").forEach((node) => {
    const target = node.getAttribute("data-include");
    if (target === "components/header.html") {
      node.innerHTML = headerTemplate;
    }
    if (target === "components/footer.html") {
      node.innerHTML = footerTemplate;
    }
  });
};

const initMobileMenu = () => {
  const menu = document.querySelector("#mobile-menu");
  const openButton = document.querySelector("#mobile-menu-toggle");
  const closeButton = document.querySelector("#mobile-menu-close");

  if (!menu || !openButton || !closeButton || menu.dataset.ready === "true") return;

  menu.dataset.ready = "true";

  openButton.addEventListener("click", () => {
    menu.classList.add("is-open");
  });

  closeButton.addEventListener("click", () => {
    menu.classList.remove("is-open");
  });

  menu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => menu.classList.remove("is-open"));
  });
};

const initStickyHeader = () => {
  const header = document.querySelector(".site-header");
  if (!header || header.dataset.stickyReady === "true") return;

  header.dataset.stickyReady = "true";

  requestAnimationFrame(() => {
    header.classList.add("is-mounted");
  });

  const syncHeaderState = () => {
    if (window.scrollY > 24) {
      header.classList.add("is-scrolled");
      return;
    }

    header.classList.remove("is-scrolled");
  };

  syncHeaderState();
  window.addEventListener("scroll", syncHeaderState, { passive: true });
};

const initLenis = () => {
  if (!window.Lenis || window.__lenisInstance) return;

  const lenis = new window.Lenis({
    duration: 0.9,
    smoothWheel: true
  });

  window.__lenisInstance = lenis;

  if (window.ScrollTrigger) {
    lenis.on("scroll", () => {
      window.ScrollTrigger.update();
    });
  }

  if (window.gsap) {
    window.gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    window.gsap.ticker.lagSmoothing(0);
    return;
  }

  const raf = (time) => {
    lenis.raf(time);
    requestAnimationFrame(raf);
  };

  requestAnimationFrame(raf);
};

const initSwiper = () => {
  if (!window.Swiper) return;

  const slider = document.querySelector(".testimonial-slider");
  if (!slider || slider.dataset.swiperReady === "true") return;

  slider.dataset.swiperReady = "true";

  new window.Swiper(slider, {
    effect: "fade",
    fadeEffect: { crossFade: true },
    loop: true,
    autoplay: {
      delay: 4000
    },
    speed: 900
  });
};

const initImageFallbacks = () => {
  const fallback = encodeURI(
    "data:image/svg+xml;charset=UTF-8," +
      `<svg xmlns='http://www.w3.org/2000/svg' width='1600' height='900' viewBox='0 0 1600 900'>
        <rect width='1600' height='900' fill='%23001d3d'/>
        <rect x='60' y='60' width='1480' height='780' rx='36' fill='%23003566' stroke='%23ffd60a' stroke-width='2' stroke-opacity='0.4'/>
        <text x='50%' y='48%' fill='%23ffd60a' font-family='Arial, sans-serif' font-size='42' text-anchor='middle' letter-spacing='8'>AUREON ESTATES</text>
        <text x='50%' y='56%' fill='white' fill-opacity='0.7' font-family='Arial, sans-serif' font-size='20' text-anchor='middle' letter-spacing='4'>PREMIUM MEDIA PLACEHOLDER</text>
      </svg>`
  );

  document.querySelectorAll("img").forEach((image) => {
    if (image.dataset.fallbackReady === "true") return;
    image.dataset.fallbackReady = "true";

    image.addEventListener("error", () => {
      if (image.dataset.fallbackApplied === "true") return;
      image.dataset.fallbackApplied = "true";
      image.src = fallback;
      image.classList.add("image-fallback");
    });
  });
};

document.addEventListener("DOMContentLoaded", () => {
  renderIncludes();
  initStickyHeader();
  initMobileMenu();
  initLenis();
  initSwiper();
  initImageFallbacks();
  document.dispatchEvent(new CustomEvent("partials:loaded"));
});

document.addEventListener("partials:loaded", () => {
  initStickyHeader();
  initMobileMenu();
  initSwiper();
  initImageFallbacks();
});
