const siteConfig = {
  brand: "Lavaforge",
  phone: "+91 98765 43210",
  email: "hello@lavaforge.studio",
  baseUrl: "https://lavaforge.studio",
  nav: [
    { href: "index.html", label: "Home" },
    { href: "pages/about.html", label: "About" },
    { href: "pages/services.html", label: "Services" },
    { href: "pages/pricing.html", label: "Pricing" },
    { href: "pages/showcase.html", label: "Showcase" },
    { href: "pages/contact.html", label: "Contact" }
  ]
};

const currentPath = window.location.pathname.replace(/\\/g, "/");
const inPagesDir = currentPath.includes("/pages/");
const basePath = inPagesDir ? "../" : "";

function normalizePath(path) {
  return path.replace(/^\.\//, "").replace(/^\//, "");
}

function isActiveLink(href) {
  const target = normalizePath(href);
  const current = normalizePath(currentPath);
  return current.endsWith(target) || ((current === "" || current.endsWith("/")) && target === "index.html");
}

function renderHeader() {
  const target = document.querySelector("[data-site-header]");
  if (!target) return;

  const navLinks = siteConfig.nav
    .map(({ href, label }) => {
      const resolved = `${basePath}${href}`;
      const active = isActiveLink(href);
      return `
        <a href="${resolved}" class="rounded-full px-4 py-2 text-sm font-semibold transition ${active ? "bg-[#780000] text-[#fdf0d5]" : "text-[#003049] hover:bg-[#003049] hover:text-[#fdf0d5]"}">${label}</a>
      `;
    })
    .join("");

  target.innerHTML = `
    <header class="sticky top-0 z-50 border-b border-[#003049]/10 bg-[#fdf0d5]/90 backdrop-blur-xl">
      <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <a href="${basePath}index.html" class="flex items-center gap-3">
          <span class="grid h-11 w-11 place-items-center rounded-full bg-[#780000] text-lg font-bold text-[#fdf0d5] shadow-lg shadow-[#780000]/20">L</span>
          <div>
            <p class="font-display text-lg font-bold tracking-tight text-[#003049]">Lavaforge Studio</p>
            <p class="text-xs uppercase tracking-[0.35em] text-[#669bbc]">Immersive Digital Brand</p>
          </div>
        </a>
        <nav class="hidden items-center gap-2 lg:flex">${navLinks}</nav>
        <div class="hidden lg:block">
          <a href="${basePath}pages/contact.html" class="rounded-full bg-[#c1121f] px-5 py-3 text-sm font-semibold text-[#fdf0d5] transition hover:bg-[#780000]">Book a Strategy Call</a>
        </div>
        <button type="button" class="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#003049]/15 text-[#003049] lg:hidden" data-menu-toggle aria-label="Toggle navigation">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        </button>
      </div>
      <div class="hidden border-t border-[#003049]/10 bg-[#fdf0d5] px-4 py-4 lg:hidden" data-mobile-menu>
        <div class="flex flex-col gap-3">
          ${siteConfig.nav
            .map(({ href, label }) => `<a href="${basePath}${href}" class="rounded-2xl border border-[#003049]/10 px-4 py-3 font-semibold text-[#003049]">${label}</a>`)
            .join("")}
          <a href="${basePath}pages/contact.html" class="rounded-2xl bg-[#c1121f] px-4 py-3 text-center font-semibold text-[#fdf0d5]">Book a Strategy Call</a>
        </div>
      </div>
    </header>
  `;
}

function renderFooter() {
  const target = document.querySelector("[data-site-footer]");
  if (!target) return;

  target.innerHTML = `
    <footer class="border-t border-[#003049]/10 bg-[#003049] text-[#fdf0d5]">
      <div class="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.2fr_0.8fr_0.8fr] lg:px-8">
        <div>
          <p class="font-display text-3xl font-bold">Build a digital experience that feels cinematic.</p>
          <p class="mt-4 max-w-xl text-sm leading-7 text-[#fdf0d5]/75">Lavaforge crafts high-conversion websites with motion, story, and premium visual systems tuned for modern brands that want to stand out fast.</p>
        </div>
        <div>
          <p class="text-sm font-semibold uppercase tracking-[0.35em] text-[#669bbc]">Navigate</p>
          <div class="mt-5 flex flex-col gap-3 text-sm">
            ${siteConfig.nav.map(({ href, label }) => `<a href="${basePath}${href}" class="transition hover:text-[#669bbc]">${label}</a>`).join("")}
          </div>
        </div>
        <div>
          <p class="text-sm font-semibold uppercase tracking-[0.35em] text-[#669bbc]">Contact</p>
          <div class="mt-5 space-y-3 text-sm text-[#fdf0d5]/75">
            <p>${siteConfig.email}</p>
            <p>${siteConfig.phone}</p>
            <p>Mumbai, India</p>
          </div>
        </div>
      </div>
      <div class="border-t border-white/10">
        <div class="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-5 text-xs text-[#fdf0d5]/60 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
          <p>&copy; <span data-current-year></span> Lavaforge Studio. Crafted for performance and premium UX.</p>
          <p>Fast-loading layouts, semantic HTML, share-ready metadata, and responsive interaction design.</p>
        </div>
      </div>
    </footer>
  `;
}

function initMenu() {
  const toggle = document.querySelector("[data-menu-toggle]");
  const menu = document.querySelector("[data-mobile-menu]");
  if (!toggle || !menu) return;
  toggle.addEventListener("click", () => {
    menu.classList.toggle("hidden");
  });
}

function initReveal() {
  const elements = document.querySelectorAll(".reveal");
  if (!elements.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.16 }
  );

  elements.forEach((element) => observer.observe(element));
}

function initCursor() {
  if (!window.matchMedia("(pointer:fine)").matches) return;

  const ring = document.querySelector("[data-cursor-ring]");
  const dot = document.querySelector("[data-cursor-dot]");
  if (!ring || !dot) return;

  let pointerX = window.innerWidth / 2;
  let pointerY = window.innerHeight / 2;
  let ringX = pointerX;
  let ringY = pointerY;

  document.body.classList.add("cursor-ready");

  window.addEventListener("mousemove", (event) => {
    pointerX = event.clientX;
    pointerY = event.clientY;
    dot.style.transform = `translate3d(${pointerX}px, ${pointerY}px, 0)`;
  });

  const animateRing = () => {
    ringX += (pointerX - ringX) * 0.16;
    ringY += (pointerY - ringY) * 0.16;
    ring.style.transform = `translate3d(${ringX}px, ${ringY}px, 0)`;
    requestAnimationFrame(animateRing);
  };

  animateRing();
}

function initSpotlightCards() {
  if (!window.matchMedia("(pointer:fine)").matches) return;

  document.querySelectorAll("[data-tilt]").forEach((card) => {
    card.addEventListener("mousemove", (event) => {
      const rect = card.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const rotateX = ((y / rect.height) - 0.5) * -12;
      const rotateY = ((x / rect.width) - 0.5) * 12;
      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });

    card.addEventListener("mouseleave", () => {
      card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg)";
    });
  });
}

function initYear() {
  document.querySelectorAll("[data-current-year]").forEach((node) => {
    node.textContent = new Date().getFullYear();
  });
}

function initMarqueePause() {
  document.querySelectorAll("[data-marquee]").forEach((marquee) => {
    marquee.addEventListener("mouseenter", () => {
      marquee.style.animationPlayState = "paused";
    });
    marquee.addEventListener("mouseleave", () => {
      marquee.style.animationPlayState = "running";
    });
  });
}

function initContactForm() {
  const form = document.querySelector("[data-contact-form]");
  if (!form) return;

  const status = document.querySelector("[data-form-status]");
  const button = form.querySelector("button[type='submit']");

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const data = new FormData(form);
    const fullName = String(data.get("full_name") || "").trim();
    const email = String(data.get("email") || "").trim();
    const projectType = String(data.get("project_type") || "").trim();
    const timeline = String(data.get("timeline") || "").trim();
    const goals = String(data.get("goals") || "").trim();

    if (!fullName || !email || !projectType || !goals) {
      if (status) {
        status.textContent = "Please complete the required fields so we can build a strong brief.";
        status.className = "rounded-2xl border border-[#c1121f]/20 bg-[#c1121f]/10 px-4 py-3 text-sm font-medium text-[#780000]";
      }
      return;
    }

    const subject = encodeURIComponent(`Project brief from ${fullName}`);
    const body = encodeURIComponent(
      [
        `Name: ${fullName}`,
        `Email: ${email}`,
        `Project Type: ${projectType}`,
        `Timeline: ${timeline || "Not specified"}`,
        "",
        "Project Goals:",
        goals
      ].join("\n")
    );

    if (status) {
      status.textContent = "Your email app is opening with the project brief pre-filled.";
      status.className = "rounded-2xl border border-[#003049]/10 bg-[#003049]/5 px-4 py-3 text-sm font-medium text-[#003049]";
    }

    if (button) {
      button.disabled = true;
      button.textContent = "Preparing Brief...";
    }

    window.location.href = `mailto:${siteConfig.email}?subject=${subject}&body=${body}`;

    window.setTimeout(() => {
      if (button) {
        button.disabled = false;
        button.textContent = "Send Project Brief";
      }
      form.reset();
    }, 1200);
  });
}

renderHeader();
renderFooter();

document.addEventListener("DOMContentLoaded", () => {
  initMenu();
  initReveal();
  initCursor();
  initSpotlightCards();
  initYear();
  initMarqueePause();
  initContactForm();
});
