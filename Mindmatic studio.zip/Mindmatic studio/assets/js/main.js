const mindmaticConfig = {
  brand: "Mindmatic Studio",
  email: "hello@mindmatic.studio",
  nav: [
    { href: "index.html", label: "Home" },
    { href: "about.html", label: "About" },
    { href: "services.html", label: "Services" },
    { href: "service-details.html", label: "Service Details" },
    { href: "portfolio.html", label: "Portfolio" },
    { href: "blog.html", label: "Blog" },
    { href: "contact.html", label: "Contact" }
  ]
};

function normalizePath(path) {
  return path.replace(/^\.\//, "").replace(/^\//, "");
}

function isActiveLink(href) {
  const current = normalizePath(window.location.pathname.split("/").pop() || "index.html");
  return current === normalizePath(href);
}

function headerFallback() {
  return `
    <header class="fixed left-0 right-0 top-0 z-50 border-b border-transparent bg-[#fdf0d5]/82 backdrop-blur-xl transition duration-300" data-fixed-header>
      <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <a href="index.html" class="flex items-center gap-3">
          <span class="grid h-11 w-11 place-items-center rounded-full bg-[#780000] text-lg font-bold text-[#fdf0d5] shadow-lg shadow-[#780000]/20">M</span>
          <div>
            <p class="font-display text-lg font-bold tracking-tight text-[#003049]">Mindmatic Studio</p>
            <p class="text-xs uppercase tracking-[0.35em] text-[#669bbc]">Immersive Digital Brand</p>
          </div>
        </a>
        <nav class="hidden items-center gap-2 lg:flex" data-nav-slot></nav>
        <div class="hidden lg:block">
          <a href="contact.html" class="rounded-full bg-[#c1121f] px-5 py-3 text-sm font-semibold text-[#fdf0d5] transition hover:bg-[#780000]">Book a Strategy Call</a>
        </div>
        <button type="button" class="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#003049]/15 text-[#003049] lg:hidden" data-menu-toggle aria-label="Toggle navigation">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        </button>
      </div>
      <div class="hidden border-t border-[#003049]/10 bg-[#fdf0d5] px-4 py-4 lg:hidden" data-mobile-menu>
        <div class="flex flex-col gap-3" data-mobile-nav-slot></div>
      </div>
    </header>
  `;
}

function initFixedHeader() {
  const header = document.querySelector("[data-fixed-header]");
  if (!header) return;

  const setOffset = () => {
    document.body.classList.add("has-fixed-header");
    document.body.style.setProperty("--header-offset", `${header.offsetHeight}px`);
  };

  const syncScrolledState = () => {
    header.classList.toggle("is-scrolled", window.scrollY > 12);
  };

  setOffset();
  syncScrolledState();
  window.addEventListener("resize", setOffset);
  window.addEventListener("scroll", syncScrolledState, { passive: true });
}

function footerFallback() {
  return `
    <footer class="border-t border-[#003049]/10 bg-[#003049] text-[#fdf0d5]">
      <div class="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.2fr_0.8fr_0.8fr] lg:px-8">
        <div>
          <p class="font-display text-3xl font-bold">Build a digital experience that feels cinematic.</p>
          <p class="mt-4 max-w-xl text-sm leading-7 text-[#fdf0d5]/75">Mindmatic crafts high-conversion websites with motion, story, and premium visual systems tuned for modern brands that want to stand out fast.</p>
        </div>
        <div>
          <p class="text-sm font-semibold uppercase tracking-[0.35em] text-[#669bbc]">Navigate</p>
          <div class="mt-5 flex flex-col gap-3 text-sm" data-footer-nav-slot></div>
        </div>
        <div>
          <p class="text-sm font-semibold uppercase tracking-[0.35em] text-[#669bbc]">Contact</p>
          <div class="mt-5 space-y-3 text-sm text-[#fdf0d5]/75">
            <p>hello@mindmatic.studio</p>
            <p>+91 98765 43210</p>
            <p>Mumbai, India</p>
          </div>
        </div>
      </div>
      <div class="border-t border-white/10">
        <div class="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-5 text-xs text-[#fdf0d5]/60 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
          <p>&copy; <span data-current-year></span> Mindmatic Studio. Crafted for performance and premium UX.</p>
          <p>Fast-loading layouts, semantic HTML, share-ready metadata, and responsive interaction design.</p>
        </div>
      </div>
    </footer>
  `;
}

function hydrateNav() {
  const desktop = document.querySelector("[data-nav-slot]");
  const mobile = document.querySelector("[data-mobile-nav-slot]");
  const footer = document.querySelector("[data-footer-nav-slot]");
  const links = mindmaticConfig.nav
    .map(({ href, label }) => {
      const active = isActiveLink(href);
      return `<a href="${href}" class="rounded-full px-4 py-2 text-sm font-semibold transition ${active ? "bg-[#780000] text-[#fdf0d5]" : "text-[#003049] hover:bg-[#003049] hover:text-[#fdf0d5]"}">${label}</a>`;
    })
    .join("");
  const mobileLinks = mindmaticConfig.nav
    .map(({ href, label }) => `<a href="${href}" class="rounded-2xl border border-[#003049]/10 px-4 py-3 font-semibold text-[#003049]">${label}</a>`)
    .join("");
  const footerLinks = mindmaticConfig.nav
    .map(({ href, label }) => `<a href="${href}" class="transition hover:text-[#669bbc]">${label}</a>`)
    .join("");

  if (desktop) desktop.innerHTML = links;
  if (mobile) mobile.innerHTML = `${mobileLinks}<a href="contact.html" class="rounded-2xl bg-[#c1121f] px-4 py-3 text-center font-semibold text-[#fdf0d5]">Book a Strategy Call</a>`;
  if (footer) footer.innerHTML = footerLinks;
}

function initMenu() {
  const toggle = document.querySelector("[data-menu-toggle]");
  const menu = document.querySelector("[data-mobile-menu]");
  if (!toggle || !menu) return;
  toggle.addEventListener("click", () => {
    menu.classList.toggle("hidden");
  });
}

function initYear() {
  document.querySelectorAll("[data-current-year]").forEach((node) => {
    node.textContent = new Date().getFullYear();
  });
}

function initContactForm() {
  const form = document.querySelector("[data-contact-form]");
  if (!form) return;

  const status = document.querySelector("[data-form-status]");
  const button = form.querySelector("button[type='submit']");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const fullName = String(data.get("full_name") || "").trim();
    const email = String(data.get("email") || "").trim();
    const projectType = String(data.get("project_type") || "").trim();
    const timeline = String(data.get("timeline") || "").trim();
    const goals = String(data.get("goals") || "").trim();

    if (!fullName || !email || !projectType || !goals) {
      if (status) {
        status.textContent = "Please complete the required fields so we can build a strong brief.";
        status.className = "rounded-2xl border border-[#c1121f]/20 bg-[#c1121f]/10 px-4 py-3 text-sm font-medium text-[#780000]";
      }
      return;
    }

    const subject = encodeURIComponent(`Project brief from ${fullName}`);
    const body = encodeURIComponent(
      [`Name: ${fullName}`, `Email: ${email}`, `Project Type: ${projectType}`, `Timeline: ${timeline || "Not specified"}`, "", "Project Goals:", goals].join("\n")
    );

    if (status) {
      status.textContent = "Your email app is opening with the project brief pre-filled.";
      status.className = "rounded-2xl border border-[#003049]/10 bg-[#003049]/5 px-4 py-3 text-sm font-medium text-[#003049]";
    }

    if (button) {
      button.disabled = true;
      button.textContent = "Preparing Brief...";
    }

    window.location.href = `mailto:${mindmaticConfig.email}?subject=${subject}&body=${body}`;

    window.setTimeout(() => {
      if (button) {
        button.disabled = false;
        button.textContent = "Send Project Brief";
      }
      form.reset();
    }, 1200);
  });
}

async function injectComponent(selector, path, fallbackMarkup) {
  const target = document.querySelector(selector);
  if (!target) return;

  try {
    const response = await fetch(path);
    if (!response.ok) throw new Error("fetch failed");
    target.innerHTML = await response.text();
  } catch {
    target.innerHTML = fallbackMarkup;
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  await injectComponent("[data-site-header]", "components/header.html", headerFallback());
  await injectComponent("[data-site-footer]", "components/footer.html", footerFallback());
  hydrateNav();
  initFixedHeader();
  initMenu();
  initYear();
  initContactForm();
  window.MindmaticScroll?.initLenis();
  window.MindmaticScroll?.initReveal();
  window.MindmaticScroll?.initParallax();
  window.MindmaticScroll?.initMarqueePause();
  window.MindmaticCursor?.initCursor();
  window.MindmaticAnimations?.initGsapSections();
  window.MindmaticAnimations?.initSpotlightCards();
  window.MindmaticAnimations?.initMagnetic();
});
