window.MindmaticCursor = (() => {
  function initCursor() {
    if (!window.matchMedia("(pointer:fine)").matches) return;

    const ring = document.querySelector("[data-cursor-ring]");
    const dot = document.querySelector("[data-cursor-dot]");
    if (!ring || !dot) return;

    let pointerX = window.innerWidth / 2;
    let pointerY = window.innerHeight / 2;
    let ringX = pointerX;
    let ringY = pointerY;

    document.body.classList.add("cursor-ready");

    window.addEventListener("mousemove", (event) => {
      pointerX = event.clientX;
      pointerY = event.clientY;
      dot.style.transform = `translate3d(${pointerX}px, ${pointerY}px, 0)`;
    });

    const animateRing = () => {
      ringX += (pointerX - ringX) * 0.16;
      ringY += (pointerY - ringY) * 0.16;
      ring.style.transform = `translate3d(${ringX}px, ${ringY}px, 0)`;
      requestAnimationFrame(animateRing);
    };

    animateRing();
  }

  return { initCursor };
})();
