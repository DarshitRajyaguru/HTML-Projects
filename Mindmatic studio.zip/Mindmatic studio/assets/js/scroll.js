window.MindmaticScroll = (() => {
  let lenisInstance = null;

  function initLenis() {
    const enableSmoothScroll = document.body.hasAttribute("data-smooth-scroll");
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!enableSmoothScroll || prefersReducedMotion || typeof window.Lenis !== "function") return;

    lenisInstance = new window.Lenis({
      smoothWheel: true,
      duration: 0.75,
      lerp: 0.12
    });

    function raf(time) {
      lenisInstance.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);
  }

  function initReveal() {
    const elements = document.querySelectorAll(".reveal");
    if (!elements.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.16 }
    );

    elements.forEach((element) => observer.observe(element));
  }

  function initParallax() {
    if (!window.matchMedia("(pointer:fine)").matches) return;

    const elements = Array.from(document.querySelectorAll("[data-parallax]"));
    if (!elements.length) return;

    let pointerX = window.innerWidth / 2;
    let pointerY = window.innerHeight / 2;
    let frameRequested = false;

    const render = () => {
      elements.forEach((element) => {
        const speed = Number(element.getAttribute("data-parallax")) || 12;
        const x = (window.innerWidth / 2 - pointerX) / speed;
        const y = (window.innerHeight / 2 - pointerY) / speed;
        element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      });
      frameRequested = false;
    };

    window.addEventListener("mousemove", (event) => {
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (!frameRequested) {
        frameRequested = true;
        requestAnimationFrame(render);
      }
    });
  }

  function initMarqueePause() {
    document.querySelectorAll("[data-marquee]").forEach((marquee) => {
      marquee.addEventListener("mouseenter", () => {
        marquee.style.animationPlayState = "paused";
      });
      marquee.addEventListener("mouseleave", () => {
        marquee.style.animationPlayState = "running";
      });
    });
  }

  return { initLenis, initReveal, initParallax, initMarqueePause };
})();
