window.MindmaticAnimations = (() => {
  function initGsapSections() {
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion || !window.gsap || !window.ScrollTrigger || !window.gsap.utils) return;
    if (window.gsap.registerPlugin) {
      window.gsap.registerPlugin(window.ScrollTrigger);
    }

    window.gsap.utils.toArray(".section-shell").forEach((section) => {
      window.gsap.fromTo(
        section,
        { opacity: 0.92, y: 28 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%"
          }
        }
      );
    });
  }

  function initSpotlightCards() {
    if (!window.matchMedia("(pointer:fine)").matches) return;

    document.querySelectorAll("[data-tilt]").forEach((card) => {
      let frameRequested = false;
      let nextTransform = "perspective(1000px) rotateX(0deg) rotateY(0deg)";

      card.addEventListener("mousemove", (event) => {
        const rect = card.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        const rotateX = ((y / rect.height) - 0.5) * -12;
        const rotateY = ((x / rect.width) - 0.5) * 12;
        nextTransform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        if (!frameRequested) {
          frameRequested = true;
          requestAnimationFrame(() => {
            card.style.transform = nextTransform;
            frameRequested = false;
          });
        }
      });

      card.addEventListener("mouseleave", () => {
        card.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg)";
      });
    });
  }

  function initMagnetic() {
    if (!window.matchMedia("(pointer:fine)").matches) return;

    document.querySelectorAll("[data-magnetic]").forEach((wrap) => {
      const item = wrap.querySelector(".magnetic-item");
      if (!item) return;
      let frameRequested = false;
      let nextTransform = "translate(0, 0)";

      wrap.addEventListener("mousemove", (event) => {
        const rect = wrap.getBoundingClientRect();
        const x = event.clientX - rect.left - rect.width / 2;
        const y = event.clientY - rect.top - rect.height / 2;
        nextTransform = `translate(${x * 0.12}px, ${y * 0.12}px)`;
        if (!frameRequested) {
          frameRequested = true;
          requestAnimationFrame(() => {
            item.style.transform = nextTransform;
            frameRequested = false;
          });
        }
      });

      wrap.addEventListener("mouseleave", () => {
        item.style.transform = "translate(0, 0)";
      });
    });
  }

  return { initGsapSections, initSpotlightCards, initMagnetic };
})();
