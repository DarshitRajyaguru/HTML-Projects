document.addEventListener("DOMContentLoaded", () => {
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  initReveal();
  initActiveHeader();

  if (reducedMotion) {
    document.body.classList.add("reduced-motion");
    return;
  }

  initCursor();
  initTiltAreas();
  initFloatingMotion();
  initMagneticItems();
  initParallaxCards();
  initDriftCards();
  initOrbitPulse();
});

function initReveal() {
  const items = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  items.forEach((item) => observer.observe(item));
}

function initActiveHeader() {
  const header = document.querySelector(".site-header");
  if (!header) return;

  const update = () => {
    header.classList.toggle("is-scrolled", window.scrollY > 30);
  };

  update();
  window.addEventListener("scroll", update, { passive: true });
}

function initCursor() {
  const dot = document.querySelector(".cursor-dot");
  const ring = document.querySelector(".cursor-ring");
  if (!dot || !ring) return;

  let x = window.innerWidth / 2;
  let y = window.innerHeight / 2;
  let rx = x;
  let ry = y;

  window.addEventListener("mousemove", (event) => {
    x = event.clientX;
    y = event.clientY;
    dot.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  });

  const loop = () => {
    rx += (x - rx) * 0.14;
    ry += (y - ry) * 0.14;
    ring.style.transform = `translate3d(${rx}px, ${ry}px, 0)`;
    requestAnimationFrame(loop);
  };

  loop();

  document.querySelectorAll("a, button, .magnetic, [data-tilt-area]").forEach((item) => {
    item.addEventListener("mouseenter", () => ring.classList.add("is-active"));
    item.addEventListener("mouseleave", () => ring.classList.remove("is-active"));
  });
}

function initTiltAreas() {
  document.querySelectorAll("[data-tilt-area]").forEach((area) => {
    area.addEventListener("mousemove", (event) => {
      const rect = area.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width - 0.5) * 18;
      const y = ((event.clientY - rect.top) / rect.height - 0.5) * -18;

      area.style.setProperty("--tilt-x", `${y}deg`);
      area.style.setProperty("--tilt-y", `${x}deg`);

      area.querySelectorAll(".floating").forEach((item) => {
        const speed = Number(item.dataset.speed || 0.1);
        item.style.setProperty("--mx", `${x * speed * 8}px`);
        item.style.setProperty("--my", `${-y * speed * 8}px`);
      });
    });

    area.addEventListener("mouseleave", () => {
      area.style.setProperty("--tilt-x", "0deg");
      area.style.setProperty("--tilt-y", "0deg");
      area.querySelectorAll(".floating").forEach((item) => {
        item.style.setProperty("--mx", "0px");
        item.style.setProperty("--my", "0px");
      });
    });
  });
}

function initFloatingMotion() {
  document.querySelectorAll(".floating").forEach((item, index) => {
    item.style.setProperty("--depth", `${Number(item.dataset.depth || 0)}px`);

    const amplitude = index % 2 === 0 ? -12 : 12;
    const start = performance.now();

    const float = (now) => {
      const progress = (now - start) / (4200 + index * 500);
      const wave = Math.sin(progress * Math.PI * 2) * amplitude;
      item.style.setProperty("--float-y", `${wave}px`);
      requestAnimationFrame(float);
    };

    requestAnimationFrame(float);
  });
}

function initMagneticItems() {
  document.querySelectorAll(".magnetic").forEach((item) => {
    item.addEventListener("mousemove", (event) => {
      const rect = item.getBoundingClientRect();
      const x = event.clientX - rect.left - rect.width / 2;
      const y = event.clientY - rect.top - rect.height / 2;
      item.style.transform = `translate(${x * 0.14}px, ${y * 0.14}px)`;
    });

    item.addEventListener("mouseleave", () => {
      item.style.transform = "";
    });
  });
}

function initParallaxCards() {
  const items = document.querySelectorAll("[data-parallax]");
  if (!items.length) return;

  const update = () => {
    const viewportHeight = window.innerHeight || 1;

    items.forEach((item) => {
      const rect = item.getBoundingClientRect();
      const speed = Number(item.dataset.parallax || 0.1);
      const distance = (rect.top + rect.height / 2 - viewportHeight / 2) * speed;
      item.style.transform = `translateY(${distance * -1}px)`;
    });
  };

  update();
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
}

function initDriftCards() {
  const items = document.querySelectorAll("[data-drift]");
  if (!items.length) return;

  const update = () => {
    const viewportHeight = window.innerHeight || 1;

    items.forEach((item) => {
      const rect = item.getBoundingClientRect();
      const speed = Number(item.dataset.drift || 0.1);
      const centerOffset = rect.top + rect.height / 2 - viewportHeight / 2;
      item.style.transform = `translateY(${centerOffset * speed * -1}px)`;
    });
  };

  update();
  window.addEventListener("scroll", update, { passive: true });
  window.addEventListener("resize", update);
}

function initOrbitPulse() {
  document.querySelectorAll(".hamper-pill").forEach((item, index) => {
    const start = performance.now();
    const amplitude = 8 + index * 2;

    const pulse = (now) => {
      const progress = (now - start) / (3600 + index * 400);
      const x = Math.cos(progress * Math.PI * 2) * amplitude;
      const y = Math.sin(progress * Math.PI * 2) * amplitude * 0.6;
      item.style.setProperty("--mx", `${x}px`);
      item.style.setProperty("--my", `${y}px`);
      requestAnimationFrame(pulse);
    };

    item.classList.add("floating");
    requestAnimationFrame(pulse);
  });
}
