const page = document.body.dataset.page || "";

const headerTemplate = `
  <header class="site-header">
    <div class="container">
      <div class="header-shell">
        <a class="brand-mark magnetic" href="index.html">
          <span class="brand-kicker">Homemade</span>
          <strong>ChocoCraze</strong>
        </a>
        <nav class="site-nav">
          <a href="index.html" data-nav="home">Home</a>
          <a href="products.html" data-nav="products">Products</a>
          <a href="craftsmanship.html" data-nav="craftsmanship">Craftsmanship</a>
          <a href="contact.html" data-nav="contact">Contact</a>
        </nav>
        <a class="btn btn-choco magnetic header-cta" href="contact.html">Order Now</a>
      </div>
    </div>
  </header>
`;

const footerTemplate = `
  <footer class="site-footer">
    <div class="container">
      <div class="footer-shell">
        <div>
          <p class="eyebrow">ChocoCraze</p>
          <h3>Homemade chocolate showcase with premium motion and brand-led design.</h3>
        </div>
        <div class="footer-links">
          <a href="index.html">Home</a>
          <a href="products.html">Products</a>
          <a href="craftsmanship.html">Craftsmanship</a>
          <a href="contact.html">Contact</a>
        </div>
        <p class="footer-note">Crafted for bars, cubes, hearts, rounded chocolates, gifting launches, and immersive product storytelling.</p>
      </div>
    </div>
  </footer>
`;

const headerMount = document.querySelector("[data-site-header]");
const footerMount = document.querySelector("[data-site-footer]");

if (headerMount) {
  headerMount.innerHTML = headerTemplate;
}

if (footerMount) {
  footerMount.innerHTML = footerTemplate;
}

document.querySelectorAll("[data-nav]").forEach((link) => {
  if (link.dataset.nav === page) {
    link.classList.add("is-active");
  }
});
