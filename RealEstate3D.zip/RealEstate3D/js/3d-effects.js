// 3D Background effect utilizing Three.js for index.html hero section

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('hero-canvas');
    if (!canvas) return; // Only execute if canvas exists (on index.html)

    // Scene Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x111827, 0.002); // matches tailwind gray-900

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({
        canvas: canvas,
        alpha: true,
        antialias: true
    });

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Cap pixel ratio for performance
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.position.z = 30;

    // Create a 3D grid/wireframe landscape (reduced segments for performance)
    const geometry = new THREE.PlaneGeometry(200, 200, 25, 25);

    // Displace vertices to create terrain
    const pos = geometry.attributes.position;
    for (let i = 0; i < pos.count; i++) {
        // x, y, z -> x is pos.getX(i), y is pos.getY(i)
        // displace Z based on some pseudo-random sine wave math
        const x = pos.getX(i);
        const y = pos.getY(i);
        const z = Math.sin(x * 0.1) * Math.cos(y * 0.1) * 5 + (Math.random() * 2);
        pos.setZ(i, z);
    }

    geometry.computeVertexNormals();

    const material = new THREE.MeshStandardMaterial({
        color: 0x14b8a6, // Teal-500
        wireframe: true,
        transparent: true,
        opacity: 0.15
    });

    const plane = new THREE.Mesh(geometry, material);
    plane.rotation.x = -Math.PI / 2; // lay it flat
    plane.position.y = -10;
    scene.add(plane);

    // Add floating particles (reduced count for performance)
    const particlesGeometry = new THREE.BufferGeometry();
    const particlesCount = 200;
    const posArray = new Float32Array(particlesCount * 3);

    for (let i = 0; i < particlesCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 100;
    }

    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particlesMaterial = new THREE.PointsMaterial({
        size: 0.1,
        color: 0x3b82f6 // Blue-500
    });

    const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particlesMesh);

    // Lighting
    const pointLight = new THREE.PointLight(0x14b8a6, 2, 100);
    pointLight.position.set(0, 5, 0);
    scene.add(pointLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Build floating primitive geometry (e.g. abstract house shapes / cubes)
    const cubes = [];
    const cubeGeo = new THREE.BoxGeometry(2, 2, 2);
    const cubeMat = new THREE.MeshPhysicalMaterial({
        color: 0x111827,
        metalness: 0.9,
        roughness: 0.1,
        transparent: true,
        opacity: 0.8,
        wireframe: true,
        wireframeLinewidth: 2
    });

    for (let i = 0; i < 5; i++) {
        const mesh = new THREE.Mesh(cubeGeo, cubeMat);
        mesh.position.x = (Math.random() - 0.5) * 40;
        mesh.position.y = (Math.random() - 0.5) * 20 + 5;
        mesh.position.z = (Math.random() - 0.5) * 20;

        // Add edge lines
        const edges = new THREE.EdgesGeometry(cubeGeo);
        const line = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x14b8a6 }));
        mesh.add(line);

        scene.add(mesh);
        cubes.push({
            mesh,
            rotx: Math.random() * 0.01,
            roty: Math.random() * 0.01,
            diry: Math.random() > 0.5 ? 1 : -1,
            speedy: 0.005 + Math.random() * 0.01
        });
    }

    // Mouse interactivity
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;
    const windowHalfX = window.innerWidth / 2;
    const windowHalfY = window.innerHeight / 2;

    document.addEventListener('mousemove', (event) => {
        mouseX = (event.clientX - windowHalfX);
        mouseY = (event.clientY - windowHalfY);
    });

    // Animation Loop
    const clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);
        const elapsedTime = clock.getElapsedTime();

        // Rotate plane slightly over time
        plane.rotation.z = elapsedTime * 0.05;

        // Animate particles
        targetX = mouseX * 0.001;
        targetY = mouseY * 0.001;

        particlesMesh.rotation.y += 0.001;
        if (mouseX > 0) {
            particlesMesh.rotation.x += 0.0001;
            particlesMesh.rotation.y += 0.0001;
        }

        camera.position.x += (mouseX * 0.01 - camera.position.x) * 0.05;
        camera.position.y += (-mouseY * 0.01 - camera.position.y) * 0.05;
        camera.lookAt(scene.position);

        // Animate cubes
        cubes.forEach(c => {
            c.mesh.rotation.x += c.rotx;
            c.mesh.rotation.y += c.roty;
            c.mesh.position.y += Math.sin(elapsedTime * 2 * c.speedy * c.diry) * 0.02;
        });

        renderer.render(scene, camera);
    }

    animate();

    // Handle Window Resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
});
