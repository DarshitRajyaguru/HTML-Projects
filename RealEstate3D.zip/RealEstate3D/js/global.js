// Global Header and Footer Injector

document.addEventListener('DOMContentLoaded', () => {
    
    // Inject Header
    const headerHTML = `
        <header class="fixed w-full top-0 z-50 glass-header transition-all duration-300" id="global-header">
            <div class="container mx-auto px-6 py-4 flex justify-between items-center">
                <!-- Logo -->
                <a href="index.html" class="flex items-center gap-2 group">
                    <div class="w-10 h-10 bg-gradient-to-br from-teal-400 to-blue-500 rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform shadow-[0_0_15px_rgba(20,184,166,0.5)]">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                    </div>
                    <span class="text-2xl font-bold tracking-tight text-white group-hover:text-teal-400 transition-colors">AURA<span class="text-teal-500">.</span></span>
                </a>

                <!-- Desktop Navigation -->
                <nav class="hidden md:flex flex-1 justify-center space-x-8">
                    <a href="index.html" class="nav-link text-gray-300 hover:text-white font-medium transition relative overflow-hidden group">
                        Home
                        <span class="absolute bottom-0 left-0 w-full h-0.5 bg-teal-500 transform translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-300"></span>
                    </a>
                    <a href="properties.html" class="nav-link text-gray-300 hover:text-white font-medium transition relative overflow-hidden group">
                        Properties
                        <span class="absolute bottom-0 left-0 w-full h-0.5 bg-teal-500 transform translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-300"></span>
                    </a>
                    <a href="contact.html" class="nav-link text-gray-300 hover:text-white font-medium transition relative overflow-hidden group">
                        Contact
                        <span class="absolute bottom-0 left-0 w-full h-0.5 bg-teal-500 transform translate-x-[-101%] group-hover:translate-x-0 transition-transform duration-300"></span>
                    </a>
                </nav>

                <!-- Action Button & Mobile Menu Toggle -->
                <div class="flex items-center gap-4">
                    <a href="contact.html" class="hidden md:inline-flex items-center justify-center px-6 py-2.5 text-sm font-semibold text-gray-900 transition-all duration-300 bg-teal-500 rounded-full hover:bg-teal-400 hover:shadow-[0_0_20px_rgba(20,184,166,0.3)]">
                        Schedule Tour
                    </a>
                    
                    <button id="mobile-menu-btn" class="md:hidden text-gray-300 hover:text-white focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                    </button>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div id="mobile-menu" class="hidden md:hidden bg-gray-900 border-t border-gray-800">
                <nav class="flex flex-col px-6 py-4 space-y-4">
                    <a href="index.html" class="text-gray-300 hover:text-white hover:bg-gray-800 px-4 py-2 rounded-lg font-medium transition">Home</a>
                    <a href="properties.html" class="text-gray-300 hover:text-white hover:bg-gray-800 px-4 py-2 rounded-lg font-medium transition">Properties</a>
                    <a href="contact.html" class="text-gray-300 hover:text-white hover:bg-gray-800 px-4 py-2 rounded-lg font-medium transition">Contact</a>
                    <a href="contact.html" class="text-center px-4 py-2 bg-teal-500 text-gray-900 rounded-lg font-bold mt-4">Schedule Tour</a>
                </nav>
            </div>
        </header>
    `;

    // Inject Footer
    const footerHTML = `
        <footer class="bg-gray-950 border-t border-gray-800 pt-20 pb-10 relative overflow-hidden">
            <!-- Footer background element -->
            <div class="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-teal-500/50 to-transparent"></div>
            
            <div class="container mx-auto px-6 relative z-10">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
                    <div class="col-span-1 md:col-span-1">
                        <a href="index.html" class="flex items-center gap-2 mb-6">
                            <div class="w-8 h-8 bg-gradient-to-br from-teal-400 to-blue-500 rounded flex items-center justify-center">
                                <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                            </div>
                            <span class="text-xl font-bold tracking-tight text-white">AURA.</span>
                        </a>
                        <p class="text-gray-400 leading-relaxed text-sm">Pioneering the future of luxury real estate through immersive 3D technology and modern architectural excellence.</p>
                    </div>
                    
                    <div>
                        <h4 class="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Quick Links</h4>
                        <ul class="space-y-4">
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">About Us</a></li>
                            <li><a href="properties.html" class="text-gray-400 hover:text-teal-400 transition text-sm">Exclusive Listings</a></li>
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">3D Virtual Tours</a></li>
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">Investment Guide</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 class="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Legal & Terms</h4>
                        <ul class="space-y-4">
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">Privacy Policy</a></li>
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">Terms of Service</a></li>
                            <li><a href="#" class="text-gray-400 hover:text-teal-400 transition text-sm">Fair Housing Act</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 class="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Newsletter</h4>
                        <p class="text-gray-400 text-sm mb-4">Subscribe for exclusive pre-market access globally.</p>
                        <form class="flex">
                            <input type="email" placeholder="Enter your email" class="w-full bg-gray-900 border border-gray-700 rounded-l-lg px-4 py-2 text-white focus:outline-none focus:border-teal-500 text-sm">
                            <button type="submit" class="bg-teal-500 hover:bg-teal-400 text-gray-900 px-4 py-2 rounded-r-lg font-semibold transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
                    <p class="text-gray-500 text-sm">© 2026 Aura Residences. All rights reserved.</p>
                    <div class="flex space-x-6 mt-4 md:mt-0">
                        <a href="#" class="text-gray-500 hover:text-white transition"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg></a>
                        <a href="#" class="text-gray-500 hover:text-white transition"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg></a>
                    </div>
                </div>
            </div>
        </footer>
    `;

    // Try injecting into placeholders if they exist
    const headerContainer = document.getElementById('header-container');
    const footerContainer = document.getElementById('footer-container');

    if(headerContainer) headerContainer.innerHTML = headerHTML;
    if(footerContainer) footerContainer.innerHTML = footerHTML;

    // Active state highlighting for nav links
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        if(link.getAttribute('href') === currentPath) {
            link.classList.add('text-teal-400');
            link.classList.remove('text-gray-300');
            const indicator = link.querySelector('span');
            if(indicator) {
                indicator.classList.remove('translate-x-[-101%]');
                indicator.classList.add('translate-x-0');
            }
        }
    });

    // Mobile menu toggling
    const btn = document.getElementById('mobile-menu-btn');
    const menu = document.getElementById('mobile-menu');
    
    if(btn && menu) {
        btn.addEventListener('click', () => {
            menu.classList.toggle('hidden');
        });
    }

    // Sticky header shadow on scroll
    const header = document.getElementById('global-header');
    window.addEventListener('scroll', () => {
        if(window.scrollY > 10) {
            header.classList.add('shadow-[0_4px_30px_rgba(0,0,0,0.5)]');
        } else {
            header.classList.remove('shadow-[0_4px_30px_rgba(0,0,0,0.5)]');
        }
    });
});
