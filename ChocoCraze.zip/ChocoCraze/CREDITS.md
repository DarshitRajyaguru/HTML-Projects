# ChocoCraze Media Credits

This site uses real chocolate product photography from Pexels, which provides free-to-use stock media under the Pexels License:

- https://www.pexels.com/license/

Images referenced in the site:

- Assorted chocolates hero image by Polina Tankilevitch: https://www.pexels.com/photo/photo-of-assorted-chocolates-4110099/
- Chocolate bar image by Lisa from Pexels: https://www.pexels.com/photo/close-up-photo-of-stacked-chocolates-bars-beside-raspberries-918327/
- Heart chocolate image by freestocks.org: https://www.pexels.com/photo/heart-shaped-chocolates-867464/
- Gift hamper image by omer celik: https://www.pexels.com/photo/chocolate-box-as-gift-17542166/
- Assorted premium chocolates image by jordan besson: https://www.pexels.com/photo/luxurious-assorted-chocolates-in-a-box-29188958/
- Truffle box image by Alina Matveycheva: https://www.pexels.com/photo/chocolate-truffles-in-box-15510969/
- Homemade truffle bowl image by Livilla Latini: https://www.pexels.com/photo/chocolate-truffles-in-a-bowl-on-a-wooden-table-27850067/

If you want to make the project fully offline later, download the same licensed images and host them locally inside `assets/images/`.
