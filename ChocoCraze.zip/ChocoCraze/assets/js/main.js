const revealItems = document.querySelectorAll(".reveal");
const tiltCards = document.querySelectorAll(".tilt-card");
const rippleTargets = document.querySelectorAll(".ripple-target");
const magneticButtons = document.querySelectorAll(".magnetic");

const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add("is-visible");
    observer.unobserve(entry.target);
  });
}, {
  threshold: 0.16,
});

revealItems.forEach((item) => revealObserver.observe(item));

tiltCards.forEach((card) => {
  const reset = () => {
    card.style.transform = "";
  };

  card.addEventListener("pointermove", (event) => {
    const rect = card.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    const rotateX = ((y / rect.height) - 0.5) * -8;
    const rotateY = ((x / rect.width) - 0.5) * 10;

    card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-4px)`;
  });

  card.addEventListener("pointerleave", reset);
  card.addEventListener("pointerup", reset);
});

rippleTargets.forEach((target) => {
  target.addEventListener("click", (event) => {
    const ripple = document.createElement("span");
    const rect = target.getBoundingClientRect();
    ripple.className = "ripple";
    ripple.style.left = `${event.clientX - rect.left}px`;
    ripple.style.top = `${event.clientY - rect.top}px`;
    target.appendChild(ripple);

    window.setTimeout(() => ripple.remove(), 600);
  });
});

magneticButtons.forEach((button) => {
  const reset = () => {
    button.style.transform = "";
  };

  button.addEventListener("pointermove", (event) => {
    const rect = button.getBoundingClientRect();
    const moveX = ((event.clientX - rect.left) / rect.width - 0.5) * 12;
    const moveY = ((event.clientY - rect.top) / rect.height - 0.5) * 10;
    button.style.transform = `translate(${moveX}px, ${moveY}px)`;
  });

  button.addEventListener("pointerleave", reset);
  button.addEventListener("pointerup", reset);
});
