(() => {
  const media = window.CHOCO_MEDIA || {};
  const siteHeader = document.querySelector(".site-header");

  if (siteHeader) {
    const syncHeaderState = () => {
      const hasScrolled = window.scrollY > 12;
      siteHeader.classList.add("is-visible");
      siteHeader.classList.toggle("is-scrolled", hasScrolled);
    };

    syncHeaderState();
    window.addEventListener("scroll", syncHeaderState, { passive: true });
  }

  const createProductCard = (product) => `
    <article class="product-card reveal">
      <div class="product-image-wrap">
        <img src="${product.image}" alt="${product.name}" loading="lazy" width="420" height="500" onerror="this.closest('.product-image-wrap').classList.add('image-failed'); this.remove();">
        <img class="hover-image" src="${product.hoverImage}" alt="${product.name} alternate view" loading="lazy" width="420" height="500" onerror="this.remove();">
        <div class="image-fallback" aria-hidden="true">
          <span>${product.name}</span>
        </div>
      </div>
      <div class="product-copy">
        <span class="product-type">${product.type}</span>
        <h3>${product.name}</h3>
        <p>${product.blurb}</p>
        <div class="product-meta">
          <strong>${product.price}</strong>
          <a href="./contact.html">Enquire</a>
        </div>
      </div>
    </article>
  `;

  const featuredRoot = document.getElementById("featured-products");
  const catalogRoot = document.getElementById("catalog-grid");
  const stackRoot = document.getElementById("hero-product-stack");
  const editorialHighlight = document.getElementById("editorial-highlight");
  const hamperHighlight = document.getElementById("hamper-highlight");

  if (featuredRoot) {
    featuredRoot.innerHTML = media.featuredProducts?.slice(0, 4).map(createProductCard).join("") || "";
  }

  if (catalogRoot) {
    catalogRoot.innerHTML = media.featuredProducts?.map(createProductCard).join("") || "";
  }

  if (stackRoot) {
    stackRoot.innerHTML = (media.featuredProducts || []).slice(0, 3).map((product) => `
      <article>
        <img src="${product.image}" alt="${product.name}" loading="lazy" width="110" height="110" onerror="this.closest('article').classList.add('stack-image-failed'); this.remove();">
        <div>
          <strong>${product.name}</strong>
          <span>${product.type}</span>
        </div>
      </article>
    `).join("");
  }

  if (editorialHighlight && media.highlights?.editorial) {
    editorialHighlight.innerHTML = `<img src="${media.highlights.editorial}" alt="Featured artisan chocolate box" loading="lazy" width="800" height="800" onerror="this.closest('.image-card').classList.add('image-failed'); this.remove();"><div class="image-fallback" aria-hidden="true"><span>Chocolate collection</span></div>`;
  }

  if (hamperHighlight && media.highlights?.hamper) {
    hamperHighlight.innerHTML = `<img src="${media.highlights.hamper}" alt="Premium chocolate hamper styling" loading="lazy" width="800" height="800" onerror="this.closest('.image-card').classList.add('image-failed'); this.remove();"><div class="image-fallback" aria-hidden="true"><span>Gift hamper styling</span></div>`;
  }

  const heroSlider = document.getElementById("hero-slider");
  if (heroSlider && media.heroSlides?.length) {
    heroSlider.innerHTML = media.heroSlides.map((slide, index) => `
      <div class="hero-slide ${index === 0 ? "active" : ""}" style="background-image:url('${slide.image}')">
        <span>${slide.title}</span>
      </div>
    `).join("");

    let currentHero = 0;
    const slides = [...heroSlider.querySelectorAll(".hero-slide")];

    window.setInterval(() => {
      slides[currentHero].classList.remove("active");
      currentHero = (currentHero + 1) % slides.length;
      slides[currentHero].classList.add("active");
    }, 4200);
  }

  const experienceStage = document.getElementById("experience-stage");
  const slideControls = document.querySelectorAll("[data-slide-control]");
  let currentExperience = 0;

  const paintExperienceSlide = () => {
    if (!experienceStage || !media.experienceSlides?.length) {
      return;
    }

    const item = media.experienceSlides[currentExperience];
    experienceStage.innerHTML = `
      <article class="experience-frame">
        <img src="${item.image}" alt="${item.title}" width="900" height="620" onerror="this.closest('.experience-frame').classList.add('image-failed'); this.remove();">
        <div class="image-fallback" aria-hidden="true">
          <span>${item.title}</span>
        </div>
        <div class="experience-overlay">
          <span>${item.title}</span>
          <p>${item.description}</p>
        </div>
      </article>
    `;
  };

  if (experienceStage) {
    paintExperienceSlide();
    slideControls.forEach((control) => {
      control.addEventListener("click", () => {
        const direction = control.dataset.slideControl;
        if (direction === "next") {
          currentExperience = (currentExperience + 1) % media.experienceSlides.length;
        } else {
          currentExperience = (currentExperience - 1 + media.experienceSlides.length) % media.experienceSlides.length;
        }
        paintExperienceSlide();
      });
    });
  }

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    }, { threshold: 0.18 });

    document.querySelectorAll(".reveal").forEach((element) => observer.observe(element));
  } else {
    document.querySelectorAll(".reveal").forEach((element) => element.classList.add("visible"));
  }

  const cursorGlow = document.querySelector(".cursor-glow");
  window.addEventListener("pointermove", (event) => {
    if (cursorGlow) {
      cursorGlow.style.transform = `translate(${event.clientX - 48}px, ${event.clientY - 48}px)`;
    }

    document.querySelectorAll("[data-parallax]").forEach((element) => {
      const x = (event.clientX / window.innerWidth - 0.5) * 12;
      const y = (event.clientY / window.innerHeight - 0.5) * 12;
      element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    });
  });

  const enquiryButton = document.querySelector(".contact-form button");
  const enquiryForm = document.querySelector(".contact-form");

  if (enquiryButton && enquiryForm) {
    enquiryButton.addEventListener("click", () => {
      const formData = new FormData(enquiryForm);
      const name = formData.get("name") || "";
      const phone = formData.get("phone") || "";
      const occasion = formData.get("occasion") || "";
      const quantity = formData.get("quantity") || "";
      const message = formData.get("message") || "";
      const subject = encodeURIComponent(`Chocolate Enquiry from ${name || "Website Visitor"}`);
      const body = encodeURIComponent(
        `Name: ${name}\nPhone: ${phone}\nOccasion: ${occasion}\nQuantity: ${quantity}\n\nMessage:\n${message}`
      );

      window.location.href = `mailto:${window.CHOCO_SITE.email}?subject=${subject}&body=${body}`;
    });
  }
})();
