(() => {
  const page = document.body.dataset.page || "";
  const navItems = [
    { href: "./index.html", label: "Home", key: "home" },
    { href: "./products.html", label: "Products", key: "products" },
    { href: "./gifting.html", label: "Gift Hampers", key: "gifting" },
    { href: "./about.html", label: "About", key: "about" },
    { href: "./contact.html", label: "Contact", key: "contact" }
  ];

  const header = document.querySelector("[data-site-header]");
  const footer = document.querySelector("[data-site-footer]");

  if (header) {
    header.innerHTML = `
      <div class="site-header">
        <div class="container nav-shell">
          <a class="brand-mark" href="./index.html" aria-label="CocoaHeirloom home">
            <span class="brand-icon">C</span>
            <span>
              <strong>CocoaHeirloom</strong>
              <small>Handmade home chocolates</small>
            </span>
          </a>
          <button class="nav-toggle" type="button" aria-label="Toggle menu" aria-expanded="false">
            <span></span>
            <span></span>
          </button>
          <nav class="site-nav" aria-label="Primary navigation">
            ${navItems.map((item) => `<a href="${item.href}" class="${item.key === page ? "active" : ""}">${item.label}</a>`).join("")}
            <a class="button button-primary nav-cta" href="./contact.html">Order Now</a>
          </nav>
        </div>
      </div>
    `;
  }

  if (footer) {
    footer.innerHTML = `
      <div class="site-footer">
        <div class="container footer-grid">
          <div>
            <a class="brand-mark footer-brand" href="./index.html">
              <span class="brand-icon">C</span>
              <span>
                <strong>CocoaHeirloom</strong>
                <small>Premium handmade chocolate gifting</small>
              </span>
            </a>
            <p class="footer-copy">Homecrafted chocolate bars, cubes, multishape delights and curated hampers designed to feel rich, thoughtful and celebration ready.</p>
          </div>
          <div>
            <h3>Quick Links</h3>
            <div class="footer-links">
              ${navItems.map((item) => `<a href="${item.href}">${item.label}</a>`).join("")}
            </div>
          </div>
          <div>
            <h3>Contact</h3>
            <div class="footer-links">
              <a href="tel:+919876543210">${window.CHOCO_SITE.phone}</a>
              <a href="mailto:${window.CHOCO_SITE.email}">${window.CHOCO_SITE.email}</a>
              <span>${window.CHOCO_SITE.instagram}</span>
            </div>
          </div>
        </div>
        <div class="container footer-bottom">
          <span>© 2026 CocoaHeirloom. Crafted with care.</span>
          <span>Built for easy media and content updates.</span>
        </div>
      </div>
    `;
  }

  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");

  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("open");
    });
  }
})();
