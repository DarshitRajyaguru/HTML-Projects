window.CHOCO_SITE = {
  assetBase: "./assets",
  brandName: "CocoaHeirloom",
  phone: "+91 98765 43210",
  email: "hello@cocoaheirloom.com",
  instagram: "@cocoaheirloom",
  resolveAsset(path) {
    return `${this.assetBase}/${path.replace(/^\/+/, "")}`;
  }
};
