window.CHOCO_MEDIA = {
  heroSlides: [
    {
      image: "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=1400&q=80",
      title: "Silky bars with polished finishes"
    },
    {
      image: "https://images.unsplash.com/photo-1515037893149-de7f840978e2?auto=format&fit=crop&w=1400&q=80",
      title: "Elegant assortments for gifting moments"
    },
    {
      image: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=1400&q=80",
      title: "Handmade textures, shapes and rich cocoa drama"
    }
  ],
  featuredProducts: [
    {
      name: "Signature Bars",
      type: "Bars",
      blurb: "Smooth slabs finished with nuts, drizzles and handcrafted detailing.",
      price: "From Rs. 240",
      image: "https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Velvet Cubes",
      type: "Cubes",
      blurb: "Neat bite-sized pieces perfect for assorted premium boxes.",
      price: "From Rs. 320",
      image: "https://images.unsplash.com/photo-1515037893149-de7f840978e2?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1514996937319-344454492b37?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Molded Delights",
      type: "Multishape",
      blurb: "Playful hearts, florals and themed pieces for celebrations.",
      price: "From Rs. 350",
      image: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Grand Gift Hampers",
      type: "Hampers",
      blurb: "Curated assortments with premium presentation and celebration-ready styling.",
      price: "Custom quote",
      image: "https://images.unsplash.com/photo-1517427294546-5aa121f68e8a?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Nut Crunch Collection",
      type: "Specialty",
      blurb: "Roasted nut textures folded into rich handmade chocolate layers.",
      price: "From Rs. 300",
      image: "https://images.unsplash.com/photo-1514996937319-344454492b37?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1515037893149-de7f840978e2?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Festive Mini Boxes",
      type: "Gifting",
      blurb: "Compact premium picks for return favors and special thank-you gifting.",
      price: "From Rs. 280",
      image: "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=900&q=80",
      hoverImage: "https://images.unsplash.com/photo-1515037893149-de7f840978e2?auto=format&fit=crop&w=900&q=80"
    }
  ],
  experienceSlides: [
    {
      title: "Gloss & Detail",
      description: "Luxury visual styling for bars and topped creations.",
      image: "https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=1100&q=80"
    },
    {
      title: "Gifting Layers",
      description: "Premium box styling designed for memorable reveals.",
      image: "https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=1100&q=80"
    },
    {
      title: "Celebration Shapes",
      description: "Theme-friendly molded chocolates with a handcrafted touch.",
      image: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=1100&q=80"
    }
  ],
  highlights: {
    editorial: "https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=1200&q=80",
    hamper: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=1200&q=80"
  }
};
