# CocoaHeirloom Static Site

Simple multi-page chocolate website built with plain HTML, CSS and JavaScript.

## Structure

- `index.html` home page
- `products.html` products collection page
- `gifting.html` gift hampers page
- `about.html` brand story page
- `contact.html` enquiry page
- `assets/css/style.css` main styling and responsive layout
- `assets/js/layout.js` global sticky header and footer
- `assets/js/main.js` sliders, reveal animations, hover behavior and mouse effects
- `assets/data/media.js` central image and product data
- `assets/js/site-config.js` brand name and contact config

## Easy Content Changes

- Update chocolate images in `assets/data/media.js`
- Update product names, prices and descriptions in `assets/data/media.js`
- Update phone, email and Instagram in `assets/js/site-config.js`
- Update shared header/footer links in `assets/js/layout.js`

## Notes

- The site uses remote realistic chocolate images so they can be swapped from one place quickly.
- For best long-term speed, replace remote image URLs with optimized local files later and keep the same keys in `assets/data/media.js`.
