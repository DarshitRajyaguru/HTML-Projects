document.addEventListener("DOMContentLoaded", () => {
  if (!window.gsap) return;

  gsap.registerPlugin(ScrollTrigger);

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) {
    document.querySelectorAll(".reveal").forEach((item) => {
      item.style.opacity = "1";
      item.style.transform = "none";
    });
    return;
  }

  initHeroMotion();
  initScrollChips();
  initTicker();
  initScrollCopyBand();
  initGalleryMotion();
  initRevealAnimations();
});

function initHeroMotion() {
  const items = gsap.utils.toArray(".beer-object");
  const stage = document.querySelector("#hero-stage");
  if (!items.length || !stage) return;

  items.forEach((item, index) => {
    const amplitude = 14 + index * 4;
    const duration = 3.8 + index * 0.5;
    const shift = Number(item.dataset.scrollShift || 0);

    gsap.to(item, {
      y: `-=${amplitude}`,
      rotation: index === 0 ? -4 : index % 2 === 0 ? 6 : -7,
      duration,
      ease: "sine.inOut",
      repeat: -1,
      yoyo: true
    });

    gsap.to(item.querySelector(".object-shadow"), {
      scaleX: 0.82,
      opacity: 0.38,
      duration,
      ease: "sine.inOut",
      repeat: -1,
      yoyo: true
    });

    gsap.to(item, {
      yPercent: shift / 5,
      scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: 1.1
      }
    });
  });

  const moveItems = (event) => {
    const rect = stage.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;

    items.forEach((item) => {
      const speed = Number(item.dataset.speed || 0.1);
      gsap.to(item, {
        x: x * rect.width * speed,
        y: y * rect.height * speed,
        duration: 0.8,
        ease: "power3.out",
        overwrite: "auto"
      });
    });
  };

  const resetItems = () => {
    items.forEach((item) => {
      gsap.to(item, {
        x: 0,
        y: 0,
        duration: 1,
        ease: "power3.out"
      });
    });
  };

  stage.addEventListener("mousemove", moveItems);
  stage.addEventListener("mouseleave", resetItems);
}

function initScrollChips() {
  const chips = gsap.utils.toArray(".beer-chip");
  if (!chips.length) return;

  chips.forEach((chip, index) => {
    const fromX = Number(chip.dataset.fromX || 0);
    const toX = Number(chip.dataset.toX || 0);
    const fromY = Number(chip.dataset.fromY || 0);
    const toY = Number(chip.dataset.toY || 0);
    const fromRotate = Number(chip.dataset.fromRotate || 0);
    const toRotate = Number(chip.dataset.toRotate || 0);

    gsap.fromTo(chip, {
      xPercent: fromX,
      yPercent: fromY,
      rotation: fromRotate
    }, {
      xPercent: toX,
      yPercent: toY,
      rotation: toRotate,
      ease: "none",
      scrollTrigger: {
        trigger: ".hero",
        start: "top bottom",
        end: "bottom top",
        scrub: 1 + index * 0.2
      }
    });

    gsap.to(chip, {
      y: `-=${10 + index * 5}`,
      duration: 3 + index * 0.45,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
  });
}

function initTicker() {
  const track = document.querySelector(".ticker-track");
  if (!track) return;

  gsap.to(track, {
    xPercent: -25,
    duration: 18,
    ease: "none",
    repeat: -1
  });
}

function initScrollCopyBand() {
  const track = document.querySelector("[data-scroll-copy]");
  if (!track) return;

  gsap.fromTo(track, {
    xPercent: 0
  }, {
    xPercent: -32,
    ease: "none",
    scrollTrigger: {
      trigger: ".scroll-copy-band",
      start: "top bottom",
      end: "bottom top",
      scrub: 1
    }
  });
}

function initGalleryMotion() {
  const stage = document.querySelector("[data-gallery-stage]");
  const cards = gsap.utils.toArray("[data-gallery-card]");
  if (!stage || !cards.length) return;

  cards.forEach((card, index) => {
    const depth = Number(card.dataset.depth || 1);
    const direction = index % 2 === 0 ? 1 : -1;

    gsap.fromTo(card, {
      y: 36 * direction,
      rotation: 1.5 * direction
    }, {
      y: -22 * direction,
      rotation: -2.2 * direction,
      ease: "none",
      scrollTrigger: {
        trigger: stage,
        start: "top 85%",
        end: "bottom top",
        scrub: 1.2
      }
    });

    gsap.to(card, {
      y: `-=${8 + index * 3}`,
      duration: 3.4 + index * 0.35,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
  });

  const moveCards = (event) => {
    const rect = stage.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;

    cards.forEach((card) => {
      const depth = Number(card.dataset.depth || 1);
      gsap.to(card, {
        x: x * 14 * depth,
        y: y * 12 * depth,
        duration: 0.8,
        ease: "power3.out",
        overwrite: "auto"
      });
    });
  };

  const resetCards = () => {
    cards.forEach((card) => {
      gsap.to(card, {
        x: 0,
        y: 0,
        duration: 1,
        ease: "power3.out"
      });
    });
  };

  stage.addEventListener("mousemove", moveCards);
  stage.addEventListener("mouseleave", resetCards);
}

function initRevealAnimations() {
  const items = gsap.utils.toArray(".reveal");
  if (!items.length) return;

  items.forEach((item) => {
    gsap.to(item, {
      opacity: 1,
      y: 0,
      duration: 0.9,
      ease: "power3.out",
      scrollTrigger: {
        trigger: item,
        start: "top 84%"
      }
    });
  });
}
