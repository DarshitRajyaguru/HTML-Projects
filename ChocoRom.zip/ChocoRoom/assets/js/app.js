const STORAGE_KEY = "chococraze-cart";

const products = [
  {
    id: "velvet-truffle-box",
    name: "Velvet Truffle Box",
    category: "truffles",
    price: 24,
    rating: 4.9,
    badge: "Bestseller",
    image: "assets/images/truffle-stack.svg",
    meta: "Assorted truffles",
    description: "Silky dark, hazelnut praline, and raspberry ganache truffles in a premium gift box."
  },
  {
    id: "sea-salt-almond-bar",
    name: "Sea Salt Almond Bar",
    category: "bars",
    price: 12,
    rating: 4.8,
    badge: "Signature",
    image: "assets/images/choco-bar.svg",
    meta: "Dark chocolate bar",
    description: "Crunchy roasted almonds folded into smooth dark chocolate with delicate sea salt flakes."
  },
  {
    id: "celebration-gift-box",
    name: "Celebration Gift Box",
    category: "gift-boxes",
    price: 36,
    rating: 5,
    badge: "Gift favorite",
    image: "assets/images/gift-box.svg",
    meta: "12-piece collection",
    description: "A curated premium box designed for birthdays, festive gifting, and elegant celebrations."
  },
  {
    id: "golden-praline",
    name: "Golden Praline",
    category: "pralines",
    price: 14,
    rating: 4.7,
    badge: "New",
    image: "assets/images/praline-gold.svg",
    meta: "Nut praline bite",
    description: "Buttery caramelized nut pralines finished with cocoa dust and a soft golden glow."
  },
  {
    id: "atelier-assortment",
    name: "Atelier Assortment",
    category: "gift-boxes",
    price: 42,
    rating: 4.9,
    badge: "Limited",
    image: "assets/images/cacao-collection.svg",
    meta: "Luxury assortment",
    description: "A premium mix of bars, pralines, and filled chocolates made for tasting nights and gifting."
  },
  {
    id: "orange-zest-bar",
    name: "Orange Zest Bar",
    category: "bars",
    price: 13,
    rating: 4.6,
    badge: "Citrus note",
    image: "assets/images/choco-bar.svg",
    meta: "Flavored dark bar",
    description: "Velvety dark chocolate layered with bright candied orange peel and a rich cocoa finish."
  }
];

const formatPrice = (value) => `$${value.toFixed(2)}`;

const getCart = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
};

const saveCart = (cart) => localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
const findProduct = (id) => products.find((product) => product.id === id);

const getCartDetails = () =>
  getCart()
    .map((item) => {
      const product = findProduct(item.id);
      return product ? { ...product, quantity: item.quantity } : null;
    })
    .filter(Boolean);

const getCartCount = () => getCart().reduce((sum, item) => sum + item.quantity, 0);
const getCartSubtotal = () => getCartDetails().reduce((sum, item) => sum + item.price * item.quantity, 0);

function updateCartCount() {
  document.querySelectorAll("[data-cart-count]").forEach((counter) => {
    counter.textContent = getCartCount();
  });
}

function addToCart(id) {
  const cart = getCart();
  const existing = cart.find((item) => item.id === id);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ id, quantity: 1 });
  }

  saveCart(cart);
  renderCart();
  updateCartCount();
}

function updateQuantity(id, nextQuantity) {
  const cart = getCart();
  const item = cart.find((entry) => entry.id === id);
  if (!item) return;

  item.quantity = nextQuantity;
  saveCart(cart.filter((entry) => entry.quantity > 0));
  renderCart();
  updateCartCount();
}

function createProductCard(product) {
  return `
    <article class="product-card reveal">
      <div class="product-media">
        <span class="product-badge">${product.badge}</span>
        <img src="${product.image}" alt="${product.name}">
      </div>
      <div class="product-info">
        <div class="product-topline">
          <h3>${product.name}</h3>
          <span class="product-rating">${product.rating.toFixed(1)} &#9733;</span>
        </div>
        <p class="product-meta">${product.category.replace("-", " ")} | ${product.meta}</p>
        <p>${product.description}</p>
        <div class="product-bottomline">
          <div class="price-group">
            <span class="tag">${product.badge}</span>
            <div class="price">${formatPrice(product.price)}</div>
          </div>
          <button class="btn btn-gold ripple" type="button" data-add-to-cart="${product.id}">Add To Cart</button>
        </div>
      </div>
    </article>
  `;
}

function renderProducts() {
  const grid = document.querySelector("[data-product-grid]");
  if (!grid) return;

  const searchValue = document.querySelector("[data-search-input]")?.value.trim().toLowerCase() || "";
  const category = document.querySelector("[data-filter-category]")?.value || "all";
  const sortValue = document.querySelector("[data-sort-select]")?.value || "featured";

  let filtered = products.filter((product) => {
    const haystack = `${product.name} ${product.description} ${product.category} ${product.meta}`.toLowerCase();
    const matchesSearch = haystack.includes(searchValue);
    const matchesCategory = category === "all" || product.category === category;
    return matchesSearch && matchesCategory;
  });

  switch (sortValue) {
    case "price-asc":
      filtered.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      filtered.sort((a, b) => b.price - a.price);
      break;
    case "rating-desc":
      filtered.sort((a, b) => b.rating - a.rating);
      break;
    case "name-asc":
      filtered.sort((a, b) => a.name.localeCompare(b.name));
      break;
    default:
      filtered.sort((a, b) => b.rating - a.rating);
  }

  grid.innerHTML = filtered.length
    ? filtered.map(createProductCard).join("")
    : `<div class="empty-state">No chocolates match your search right now. Try another filter or keyword.</div>`;
}

function renderCart() {
  const items = getCartDetails();
  document.querySelectorAll("[data-cart-items]").forEach((container) => {
    container.innerHTML = items.length
      ? items.map((item) => `
        <article class="cart-item">
          <img src="${item.image}" alt="${item.name}">
          <div class="cart-meta">
            <strong>${item.name}</strong>
            <span>${item.meta}</span>
            <div class="quantity-controls">
              <button type="button" data-cart-change="${item.id}" data-cart-delta="-1">-</button>
              <span>${item.quantity}</span>
              <button type="button" data-cart-change="${item.id}" data-cart-delta="1">+</button>
            </div>
          </div>
          <strong>${formatPrice(item.price * item.quantity)}</strong>
        </article>
      `).join("")
      : `<div class="empty-state">Your cart is empty. Add a few artisan chocolates to get started.</div>`;
  });

  const totalNode = document.querySelector("[data-cart-total]");
  if (totalNode) totalNode.textContent = formatPrice(getCartSubtotal());
}

function initFilters() {
  const controls = [
    document.querySelector("[data-search-input]"),
    document.querySelector("[data-filter-category]"),
    document.querySelector("[data-sort-select]")
  ].filter(Boolean);

  controls.forEach((control) => {
    control.addEventListener("input", renderProducts);
    control.addEventListener("change", renderProducts);
  });
}

function initCartDrawer() {
  const drawer = document.querySelector("[data-cart-drawer]");
  if (!drawer) return;

  const openDrawer = () => {
    drawer.classList.add("active");
    drawer.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  };

  const closeDrawer = () => {
    drawer.classList.remove("active");
    drawer.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  };

  document.querySelectorAll("[data-open-cart]").forEach((button) => {
    button.addEventListener("click", openDrawer);
  });

  document.querySelectorAll("[data-close-cart]").forEach((button) => {
    button.addEventListener("click", closeDrawer);
  });
}

function initRipple() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest(".ripple");
    if (!button) return;

    const rect = button.getBoundingClientRect();
    const wave = document.createElement("span");
    wave.className = "ripple-wave";
    wave.style.left = `${event.clientX - rect.left}px`;
    wave.style.top = `${event.clientY - rect.top}px`;
    button.append(wave);
    wave.addEventListener("animationend", () => wave.remove(), { once: true });
  });
}

function initPageTransitions() {
  const overlay = document.querySelector(".page-transition");
  if (!overlay || !window.gsap) return;

  gsap.to(overlay, {
    scaleY: 0,
    duration: 0.8,
    ease: "power3.out",
    transformOrigin: "top"
  });

  if (window.location.protocol === "file:") return;

  document.querySelectorAll('a[href$=".html"]').forEach((link) => {
    const href = link.getAttribute("href");
    if (!href) return;

    link.addEventListener("click", (event) => {
      if (link.target === "_blank" || event.metaKey || event.ctrlKey) return;
      event.preventDefault();
      gsap.set(overlay, { transformOrigin: "bottom", scaleY: 0 });
      gsap.to(overlay, {
        scaleY: 1,
        duration: 0.45,
        ease: "power2.in",
        onComplete: () => {
          window.location.href = href;
        }
      });
    });
  });
}

function initCheckoutForm() {
  const form = document.querySelector("[data-checkout-form]");
  const success = document.querySelector("[data-order-success]");
  if (!form || !success) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    localStorage.setItem("chococraze-last-order", JSON.stringify(Object.fromEntries(new FormData(form).entries())));
    saveCart([]);
    renderCart();
    updateCartCount();
    form.hidden = true;
    success.hidden = false;
    success.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

document.addEventListener("click", (event) => {
  const addButton = event.target.closest("[data-add-to-cart]");
  if (addButton) {
    addToCart(addButton.dataset.addToCart);
  }

  const quantityButton = event.target.closest("[data-cart-change]");
  if (quantityButton) {
    const id = quantityButton.dataset.cartChange;
    const delta = Number(quantityButton.dataset.cartDelta);
    const current = getCart().find((item) => item.id === id)?.quantity || 0;
    updateQuantity(id, current + delta);
  }
});

document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  renderCart();
  updateCartCount();
  initFilters();
  initCartDrawer();
  initRipple();
  initPageTransitions();
  initCheckoutForm();
});
