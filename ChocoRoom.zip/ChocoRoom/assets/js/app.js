const STORAGE_KEY = "chococraze-cart";

const products = [
  {
    id: "velvet-truffle-box",
    name: "Velvet Truffle Box",
    category: "truffles",
    price: 24,
    rating: 4.9,
    badge: "Bestseller",
    image: "assets/images/truffle-stack.svg",
    description: "Assorted dark, hazelnut praline, and raspberry ganache truffles in a satin-lined gift box."
  },
  {
    id: "sea-salt-bar",
    name: "Sea Salt Almond Bar",
    category: "bars",
    price: 12,
    rating: 4.8,
    badge: "Signature",
    image: "assets/images/choco-bar.svg",
    description: "Crunchy roasted almonds folded into 64% dark chocolate with flakes of sea salt."
  },
  {
    id: "celebration-box",
    name: "Celebration Gift Box",
    category: "gift-boxes",
    price: 36,
    rating: 5,
    badge: "Gift favorite",
    image: "assets/images/gift-box.svg",
    description: "A premium 12-piece experience box curated for birthdays, anniversaries, and festive gifting."
  },
  {
    id: "golden-praline",
    name: "Golden Praline",
    category: "pralines",
    price: 14,
    rating: 4.7,
    badge: "New",
    image: "assets/images/praline-gold.svg",
    description: "Buttery caramelized nut pralines finished with cocoa dust and a soft golden sheen."
  },
  {
    id: "atelier-assortment",
    name: "Atelier Assortment",
    category: "gift-boxes",
    price: 42,
    rating: 4.9,
    badge: "Limited",
    image: "assets/images/cacao-collection.svg",
    description: "A seasonal collection of bars, bonbons, and truffles designed for luxurious tasting nights."
  },
  {
    id: "orange-zest-bar",
    name: "Orange Zest Dark Bar",
    category: "bars",
    price: 13,
    rating: 4.6,
    badge: "Citrus note",
    image: "assets/images/choco-bar.svg",
    description: "Velvety dark chocolate layered with candied orange peel and a long cocoa finish."
  }
];

const formatPrice = (value) => `$${value.toFixed(2)}`;

const getCart = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
};

const saveCart = (cart) => localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
const findProduct = (id) => products.find((product) => product.id === id);

const getCartDetails = () =>
  getCart().map((item) => {
    const product = findProduct(item.id);
    return product ? { ...product, quantity: item.quantity } : null;
  }).filter(Boolean);

const getCartCount = () => getCart().reduce((sum, item) => sum + item.quantity, 0);
const getCartSubtotal = () => getCartDetails().reduce((sum, item) => sum + item.price * item.quantity, 0);

function updateCartCount() {
  document.querySelectorAll("[data-cart-count]").forEach((counter) => {
    counter.textContent = getCartCount();
  });
}

function addToCart(id) {
  const cart = getCart();
  const existing = cart.find((item) => item.id === id);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ id, quantity: 1 });
  }

  saveCart(cart);
  renderCart();
  updateCartCount();
}

function updateQuantity(id, nextQuantity) {
  const cart = getCart();
  const item = cart.find((entry) => entry.id === id);
  if (!item) return;

  item.quantity = nextQuantity;
  saveCart(cart.filter((entry) => entry.quantity > 0));
  renderCart();
  renderCheckout();
  updateCartCount();
}

function createProductCard(product) {
  return `
    <article class="product-card">
      <div class="product-media">
        <span class="product-badge">${product.badge}</span>
        <img src="${product.image}" alt="${product.name}">
      </div>
      <div class="product-info">
        <div class="product-topline">
          <h3>${product.name}</h3>
          <span class="product-rating">${product.rating.toFixed(1)} &#9733;</span>
        </div>
        <p>${product.description}</p>
        <div class="product-bottomline">
          <div>
            <span class="tag">${product.category.replace("-", " ")}</span>
            <div class="price">${formatPrice(product.price)}</div>
          </div>
          <button class="btn btn-primary ripple" type="button" data-add-to-cart="${product.id}">Add to Cart</button>
        </div>
      </div>
    </article>
  `;
}

function renderProducts() {
  const grid = document.querySelector("[data-product-grid]");
  if (!grid) return;

  const searchValue = document.querySelector("[data-search-input]")?.value.trim().toLowerCase() || "";
  const category = document.querySelector("[data-filter-category]")?.value || "all";
  const sortValue = document.querySelector("[data-sort-select]")?.value || "featured";

  let filtered = products.filter((product) => {
    const haystack = `${product.name} ${product.description} ${product.category}`.toLowerCase();
    const matchesSearch = haystack.includes(searchValue);
    const matchesCategory = category === "all" || product.category === category;
    return matchesSearch && matchesCategory;
  });

  switch (sortValue) {
    case "price-asc":
      filtered.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      filtered.sort((a, b) => b.price - a.price);
      break;
    case "rating-desc":
      filtered.sort((a, b) => b.rating - a.rating);
      break;
    case "name-asc":
      filtered.sort((a, b) => a.name.localeCompare(b.name));
      break;
    default:
      filtered.sort((a, b) => b.rating - a.rating);
  }

  grid.innerHTML = filtered.length
    ? filtered.map(createProductCard).join("")
    : `<div class="empty-state">No chocolates match your current search. Try a different filter or keyword.</div>`;
}

function renderCart() {
  const items = getCartDetails();
  document.querySelectorAll("[data-cart-items]").forEach((container) => {
    container.innerHTML = items.length
      ? items.map((item) => `
        <article class="cart-item">
          <img src="${item.image}" alt="${item.name}">
          <div class="cart-meta">
            <strong>${item.name}</strong>
            <span>${formatPrice(item.price)} each</span>
            <div class="quantity-controls">
              <button type="button" data-cart-change="${item.id}" data-cart-delta="-1">-</button>
              <span>${item.quantity}</span>
              <button type="button" data-cart-change="${item.id}" data-cart-delta="1">+</button>
            </div>
          </div>
          <strong>${formatPrice(item.price * item.quantity)}</strong>
        </article>
      `).join("")
      : `<div class="empty-state">Your cart is empty. Add a few artisan chocolates to get started.</div>`;
  });

  const totalNode = document.querySelector("[data-cart-total]");
  if (totalNode) {
    totalNode.textContent = formatPrice(getCartSubtotal());
  }
}

function renderCheckout() {
  const container = document.querySelector("[data-checkout-items]");
  const subtotalNode = document.querySelector("[data-checkout-subtotal]");
  const deliveryNode = document.querySelector("[data-checkout-delivery]");
  const totalNode = document.querySelector("[data-checkout-total]");
  if (!container || !subtotalNode || !deliveryNode || !totalNode) return;

  const items = getCartDetails();
  const subtotal = getCartSubtotal();
  const delivery = items.length ? 8 : 0;

  container.innerHTML = items.length
    ? items.map((item) => `
      <article class="summary-item">
        <img src="${item.image}" alt="${item.name}">
        <div class="summary-meta">
          <strong>${item.name}</strong>
          <span>Qty ${item.quantity}</span>
        </div>
        <strong>${formatPrice(item.price * item.quantity)}</strong>
      </article>
    `).join("")
    : `<div class="empty-state">Your cart is empty. Visit the shop to add your favorite chocolates.</div>`;

  subtotalNode.textContent = formatPrice(subtotal);
  deliveryNode.textContent = formatPrice(delivery);
  totalNode.textContent = formatPrice(subtotal + delivery);
}

function initFilters() {
  const controls = [
    document.querySelector("[data-search-input]"),
    document.querySelector("[data-filter-category]"),
    document.querySelector("[data-sort-select]")
  ].filter(Boolean);

  controls.forEach((control) => {
    control.addEventListener("input", renderProducts);
    control.addEventListener("change", renderProducts);
  });
}

function initCartDrawer() {
  const drawer = document.querySelector("[data-cart-drawer]");
  if (!drawer) return;

  const openDrawer = () => {
    drawer.classList.add("active");
    drawer.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  };

  const closeDrawer = () => {
    drawer.classList.remove("active");
    drawer.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  };

  document.querySelectorAll("[data-open-cart]").forEach((button) => {
    button.addEventListener("click", openDrawer);
  });

  document.querySelectorAll("[data-close-cart]").forEach((button) => {
    button.addEventListener("click", closeDrawer);
  });
}

function initRipple() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest(".ripple");
    if (!button) return;

    const rect = button.getBoundingClientRect();
    const wave = document.createElement("span");
    wave.className = "ripple-wave";
    wave.style.left = `${event.clientX - rect.left}px`;
    wave.style.top = `${event.clientY - rect.top}px`;
    button.append(wave);
    wave.addEventListener("animationend", () => wave.remove(), { once: true });
  });
}

function initPageTransitions() {
  const overlay = document.querySelector(".page-transition");
  if (!overlay || !window.gsap) return;

  gsap.to(overlay, {
    scaleY: 0,
    duration: 0.8,
    ease: "power3.out",
    transformOrigin: "top"
  });

  document.querySelectorAll('a[href$=".html"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const href = link.getAttribute("href");
      if (!href || link.target === "_blank" || event.metaKey || event.ctrlKey) return;

      event.preventDefault();
      gsap.set(overlay, { transformOrigin: "bottom", scaleY: 0 });
      gsap.to(overlay, {
        scaleY: 1,
        duration: 0.45,
        ease: "power2.in",
        onComplete: () => {
          window.location.href = href;
        }
      });
    });
  });
}

function initCheckoutForm() {
  const form = document.querySelector("[data-checkout-form]");
  const success = document.querySelector("[data-order-success]");
  if (!form || !success) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    localStorage.setItem("chococraze-last-order", JSON.stringify(Object.fromEntries(new FormData(form).entries())));
    saveCart([]);
    renderCheckout();
    updateCartCount();
    form.hidden = true;
    success.hidden = false;
    success.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

document.addEventListener("click", (event) => {
  const addButton = event.target.closest("[data-add-to-cart]");
  if (addButton) {
    addToCart(addButton.dataset.addToCart);
  }

  const quantityButton = event.target.closest("[data-cart-change]");
  if (quantityButton) {
    const id = quantityButton.dataset.cartChange;
    const delta = Number(quantityButton.dataset.cartDelta);
    const current = getCart().find((item) => item.id === id)?.quantity || 0;
    updateQuantity(id, current + delta);
  }
});

document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  renderCart();
  renderCheckout();
  updateCartCount();
  initFilters();
  initCartDrawer();
  initRipple();
  initPageTransitions();
  initCheckoutForm();
});
