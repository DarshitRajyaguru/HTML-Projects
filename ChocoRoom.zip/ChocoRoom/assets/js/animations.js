document.addEventListener("DOMContentLoaded", () => {
  if (!window.gsap) return;

  gsap.registerPlugin(ScrollTrigger);

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduceMotion) {
    document.querySelectorAll(".reveal").forEach((item) => {
      item.style.opacity = "1";
      item.style.transform = "none";
    });
    return;
  }

  initHeroFloating();
  initHeroParallax();
  initScrollChocolateAccents();
  initRevealAnimations();
});

function initHeroFloating() {
  const items = gsap.utils.toArray(".floating-item");
  if (!items.length) return;

  items.forEach((item, index) => {
    const amplitude = 16 + index * 4;
    const duration = 3.8 + index * 0.4;
    const shift = Number(item.dataset.scrollShift || 0);

    gsap.to(item, {
      y: `-=${amplitude}`,
      rotation: index % 2 === 0 ? 5 : -5,
      duration,
      ease: "sine.inOut",
      repeat: -1,
      yoyo: true
    });

    gsap.to(item.querySelector(".item-shadow"), {
      scaleX: 0.82,
      opacity: 0.45,
      duration,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });

    gsap.to(item, {
      yPercent: shift / 5,
      scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: 1.2
      }
    });
  });
}

function initHeroParallax() {
  const scene = document.querySelector("#hero-scene");
  const items = gsap.utils.toArray(".floating-item");
  if (!scene || !items.length) return;

  const moveItems = (event) => {
    const rect = scene.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;

    items.forEach((item) => {
      const speed = Number(item.dataset.speed || 0.1);
      gsap.to(item, {
        x: x * rect.width * speed,
        y: y * rect.height * speed,
        duration: 0.8,
        ease: "power3.out",
        overwrite: "auto"
      });
    });
  };

  const resetItems = () => {
    items.forEach((item) => {
      gsap.to(item, {
        x: 0,
        y: 0,
        duration: 1,
        ease: "power3.out"
      });
    });
  };

  scene.addEventListener("mousemove", moveItems);
  scene.addEventListener("mouseleave", resetItems);
}

function initScrollChocolateAccents() {
  const accents = gsap.utils.toArray(".scroll-accent");
  if (!accents.length) return;

  accents.forEach((accent, index) => {
    const fromX = Number(accent.dataset.fromX || 0);
    const toX = Number(accent.dataset.toX || 0);
    const fromY = Number(accent.dataset.fromY || 0);
    const toY = Number(accent.dataset.toY || 0);
    const fromRotate = Number(accent.dataset.fromRotate || 0);
    const toRotate = Number(accent.dataset.toRotate || 0);

    gsap.fromTo(accent, {
      xPercent: fromX,
      yPercent: fromY,
      rotation: fromRotate
    }, {
      xPercent: toX,
      yPercent: toY,
      rotation: toRotate,
      ease: "none",
      scrollTrigger: {
        trigger: ".hero",
        start: "top bottom",
        end: "bottom top",
        scrub: 1 + index * 0.25
      }
    });

    gsap.to(accent, {
      y: `-=${10 + index * 4}`,
      duration: 3.4 + index * 0.45,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
  });
}

function initRevealAnimations() {
  const items = gsap.utils.toArray(".reveal");
  if (!items.length) return;

  items.forEach((item) => {
    gsap.to(item, {
      opacity: 1,
      y: 0,
      duration: 0.9,
      ease: "power3.out",
      scrollTrigger: {
        trigger: item,
        start: "top 85%"
      }
    });
  });
}
